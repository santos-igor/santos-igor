package weka.classifiers.compression.dmc;

import java.io.Serializable;

/**
 * A node for the Markov Chain Compression Model
 * adapted from the DMC.c version by G. Cormack
 * @author Igor Santos
 *
 */
public class Node implements Serializable
{
   
	private static final long serialVersionUID = -2342249703453716918L;
	private float[] count;
    private int[] next;

    public float[] getCount() {
		return count;
	}

	public void setCount(float[] count) {
		this.count = count;
	}

	public int[] getNext() {
		return next;
	}

	public void setNext(int[] next) {
		this.next = next;
	}

	

   
    public Node(float[] count, int[] next) 
    {
    	this.count = count;
        this.next = next;
    }

    public Node()
    {
    	count = new float[2];
        next =  new int[2];
        next[0] = -1;
        next[1] = -1;
    }
}
