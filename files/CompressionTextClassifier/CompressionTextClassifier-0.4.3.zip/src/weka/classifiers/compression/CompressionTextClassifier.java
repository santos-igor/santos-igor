/*
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
 *    CompressionTextClassifier.java
 */

package weka.classifiers.compression;

import weka.classifiers.AbstractClassifier;
import weka.classifiers.compression.models.*;
import weka.core.Attribute;
import weka.core.Capabilities;
import weka.core.Instance;
import weka.core.Instances;
import weka.core.Option;
import weka.core.OptionHandler;
import weka.core.RevisionUtils;
import weka.core.SelectedTag;
import weka.core.Stopwords;
import weka.core.Tag;
import weka.core.TechnicalInformation;
import weka.core.TechnicalInformationHandler;
import weka.core.Utils;
import weka.core.Capabilities.Capability;
import weka.core.TechnicalInformation.Field;
import weka.core.TechnicalInformation.Type;

import java.io.*;
import java.util.Enumeration;
import java.util.StringTokenizer;
import java.util.Vector;

/**
 * <!-- globalinfo-start --> This algorithm uses several Compression-based Text
 * Classifiers based on Variable Markov Models. <br />
 * Special credit has to be given for Begleiter, El-Yaniv and Yona for the VMM
 * algoritihms implementations, and G.V. Cormack for his original implementation
 * of DMC <br />
 * <br />
 * You can select as compression models: <br />
 * 1.- DMC_ Dynamic Markov Chain Compression Model 2.- LZ78: Lempel-Ziv 78
 * Algorithm 3.- LZMS: An Improved Lempel-Ziv Algorithm 4.- PPM: Prediction by
 * Partial Match (PPM) 5.- DECTW: Decomposed Context Tree Weighting Method (CTW)
 * for Multi-Alphabets 6.- BICTW: Binary Context Tree Weighting Method (CTW) for
 * Multi-Alphabets 7.- PST: Probabilistic Suffix Trees (PST) prediction
 * algorithm <br/>
 * <br/>
 * For more information, see<br/>
 * <br/>
 * For more information, see Ron Begleiter, Ran El-Yaniv, Golan Yona (2004). On
 * Prediction Using Variable Order Markov Models. Journal of Artificial
 * Intelligence Research (JAIR). 22:385-421. <br />
 * GV Cormack, RNS Horspool (1987). Data compression using dynamic Markov
 * modelling. The Computer Journal. 30(6):541-550.
 * <p/>
 * <!-- globalinfo-end -->
 * 
 * <p/>
 * <!-- technical-bibtex-end -->
 * 
 * <!-- options-start --> Valid options are:
 * <p/>
 * 
 * <pre>
 * -C
 *  Classification method (0 for No Adaptation of the model with the test instance, 1 for daptation of the model with the test instance)
 *  (use when k &gt; 1)
 * </pre>
 * 
 * <pre>
 * -delimiters &lt;String&gt;
 * \tThe delimiters to use\n"
 * 	+ "\t(default ' \\r\\n\\t.,;:'\"()?!').",
 *         "delimiters", 1, "-delimiters
 * </pre>
 * 
 * <pre>
 * -P 
 * If the predictions are going to be transformed to probabilities or not
 * </pre>
 * 
 * *
 * 
 * <pre>
 * -L 
 * If the messages are going to be converted to lowercase
 * </pre>
 * 
 * * </pre>
 * 
 * 
 * <pre>
 * -S
 *  Ignore words that are in the stoplist.
 * </pre>
 * 
 * <pre>
 * -stopwords &lt;file&gt;
 *  A file containing stopwords to override the default ones.
 *  Using this option automatically sets the flag ('-S') to use the
 *  stoplist if the file exists.
 *  Format: one stopword per line, lines starting with '#'
 *  are interpreted as comments and ignored.
 * </pre>
 * 
 * <!-- options-end -->
 * 
 * @author Igor Santos (isantos@deusto.es)
 * @author Patxi Gal�n-Garc�a (patxigg@deusto.es)
 * @version $Revision: 1 $
 */
public class CompressionTextClassifier extends AbstractClassifier implements
		OptionHandler, TechnicalInformationHandler {

	/** for serialization. */
	static final long serialVersionUID = -3080186098777067172L;

	/**
	 * Returns a string describing classifier.
	 * 
	 * @return a description suitable for displaying in the
	 *         explorer/experimenter gui
	 */
	public String globalInfo() {

		return "This algorithm uses several Compression-based Text Classifiers based on Variable Markov Models.\n\n Special credit has to be given to: \n" +
				"\tRon Begleiter, Ran El-Yaniv and Golan Yona for the VMM algorithms implementations \n " +
				"\t(available at: http://www.cs.technion.ac.il/~ronbeg/vmm/code_index.html), \n" +
				"\nand \n " + 
				"\tGV Cormack and RNS Horspool for his original implementation of DMC \n" +
				"\t(available at: http://www.jjj.de/crs4/dmc.c)\n"
				+ "\n\nYou can select as compression models:\n\n"
				+ "1.- DMC: Dynamic Markov Chain Compression Model\n"
				+ "2.- LZ78: Lempel-Ziv 78 Algorithm\n"
				+ "3.- LZMS: An Improved Lempel-Ziv Algorithm\n"
				+ "4.- PPM: Prediction by Partial Match (PPM)\n"
				+ "5.- DECTW: Decomposed Context Tree Weighting Method (CTW) for Multi-Alphabets\n"
				+ "6.- BICTW: Binary Context Tree Weighting Method (CTW) for Multi-Alphabets\n"
				+ "7.- PST: Probabilistic Suffix Trees (PST) prediction algorithm\n"
				+ "\n\nFor more information, see\n\n"
				+ getTechnicalInformation().toString();
	}

	/**
	 * Returns an instance of a TechnicalInformation object, containing detailed
	 * information about the technical background of this class, e.g., paper
	 * reference or book this class is based on.
	 * 
	 * @return the technical information about this class
	 */
	public TechnicalInformation getTechnicalInformation() {
		TechnicalInformation result;

		result = new TechnicalInformation(Type.ARTICLE);
		result.setValue(Field.AUTHOR,
				"Ron Begleiter and Ran El-Yaniv and Golan Yona");
		result.setValue(Field.YEAR, "2004");
		result.setValue(Field.TITLE,
				"On Prediction Using Variable Order Markov Models");
		result.setValue(Field.JOURNAL,
				"Journal of Artificial Intelligence Research (JAIR)");
		result.setValue(Field.VOLUME, "22");
		result.setValue(Field.PAGES, "385-421");

		TechnicalInformation result2;
		result2 = new TechnicalInformation(Type.ARTICLE);
		result2.setValue(Field.AUTHOR, "GV Cormack and RNS Horspool");
		result2.setValue(Field.YEAR, "1987");
		result2.setValue(Field.TITLE,
				"Data compression using dynamic Markov modelling");
		result2.setValue(Field.JOURNAL, "The Computer Journal");
		result2.setValue(Field.VOLUME, "30");
		result2.setValue(Field.NUMBER, "6");
		result2.setValue(Field.PAGES, "541-550");

		result.add(result2);

		return result;
	}

	/** for the compression */
	protected CompressionModel m_compression = new PPM();

	/**
	 * Returns the tip text for this property.
	 * 
	 * @return tip text for this property suitable for displaying in the
	 *         explorer/experimenter GUI
	 */
	public String compressionModelTipText() {
		return "The compression model to use "
				+ "(Default: weka.compression.models.PPM).";
	}

	/**
	 * Returns the current nearestNeighbourSearch algorithm in use.
	 * 
	 * @return the NearestNeighbourSearch algorithm currently in use.
	 */
	public CompressionModel getCompressionModel() {
		return m_compression;
	}

	/**
	 * Sets the compression model to be used(s).
	 * 
	 * @param compModel
	 *            - compression model to be used
	 */
	public void setCompressionModel(CompressionModel compModel) {
		m_compression = compModel;
	}

	/**
	 * The Compression models
	 */
	private CompressionModel[] compressionModels = null;

	/** The number of class values (or 1 if predicting numeric). */
	protected int m_NumClasses;

	/**
	 * The classification type (0 for Cross-Entropy 1 for MDL)
	 */
	private int m_ClassificationType = 0;

	/** Classification type: No Adaptation. */
	public static final int NA = 0;

	/** Classification type: Adaptation. */
	public static final int A = 1;

	private boolean m_lowerCaseTokens;

	/**
	 * Set the if the messages are going to be converted to lowercase
	 * 
	 * @param if the messages are going to be converted to lowercase
	 */
	public void setLowerCaseTokens(boolean k) {
		m_lowerCaseTokens = k;
	}

	/**
	 * Gets if the messages are going to be converted to lowercase
	 * 
	 * @return if the messages are going to be converted to lowercase
	 */
	public boolean getLowerCaseTokens() {

		return m_lowerCaseTokens;
	}

	/**
	 * If the predictions are going to be transformed to probabilities or not
	 */
	private boolean m_estimateProbabilities = true;

	/**
	 * Set the if the predictions are going to be transformed to probabilities
	 * or not
	 * 
	 * @param if the predictions are going to be transformed to probabilities or
	 *        not
	 */
	public void setEstimateProbabilities(boolean k) {
		m_estimateProbabilities = k;
	}

	/**
	 * Gets if the predictions are going to be transformed to probabilities or
	 * not
	 * 
	 * @return if the predictions are going to be transformed to probabilities
	 *         or not
	 */
	public boolean getEstimateProbabilities() {

		return m_estimateProbabilities;
	}

	/**
	 * a file containing stopwords for using others than the default Rainbow
	 * ones.
	 */
	private File m_Stopwords = new File(System.getProperty("user.dir"));

	/**
	 * sets the file containing the stopwords, null or a directory unset the
	 * stopwords. If the file exists, it automatically turns on the flag to use
	 * the stoplist.
	 * 
	 * @param value
	 *            the file containing the stopwords
	 */
	public void setStopwords(File value) {
		if (value == null)
			value = new File(System.getProperty("user.dir"));

		m_Stopwords = value;
		if (value.exists() && value.isFile())
			setUseStoplist(true);
	}

	/**
	 * returns the file used for obtaining the stopwords, if the file represents
	 * a directory then the default ones are used.
	 * 
	 * @return the file containing the stopwords
	 */
	public File getStopwords() {
		return m_Stopwords;
	}

	/**
	 * Returns the tip text for this property.
	 * 
	 * @return tip text for this property suitable for displaying in the
	 *         explorer/experimenter gui
	 */
	public String stopwordsTipText() {
		return "The file containing the stopwords (if this is a directory then the default ones are used).";
	}

	/** True if tokens that are on a stoplist are to be ignored. */
	private boolean m_useStoplist;

	/**
	 * Gets whether if the words on the stoplist are to be ignored (The stoplist
	 * is in weka.core.StopWords).
	 * 
	 * @return true if the words on the stoplist are to be ignored.
	 */
	public boolean getUseStoplist() {
		return m_useStoplist;
	}

	/**
	 * Sets whether if the words that are on a stoplist are to be ignored (The
	 * stop list is in weka.core.StopWords).
	 * 
	 * @param useStoplist
	 *            true if the tokens that are on a stoplist are to be ignored.
	 */
	public void setUseStoplist(boolean useStoplist) {
		m_useStoplist = useStoplist;
	}

	/**
	 * Returns the tip text for this property.
	 * 
	 * @return tip text for this property suitable for displaying in the
	 *         explorer/experimenter gui
	 */
	public String useStoplistTipText() {
		return "Ignores all the words that are on the stoplist, if set to true.";
	}

	/** Delimiters used in tokenization */
	protected String m_Delimiters = " \r\n\t.,;:'\"()?!";

	/**
	 * Get the value of delimiters (not backquoted).
	 * 
	 * @return Value of delimiters.
	 */
	public String getDelimiters() {
		return m_Delimiters;
	}

	/**
	 * Set the value of delimiters. For convenienve, the strings "\r", "\n",
	 * "\t", "\'", "\\" get automatically translated into their character
	 * representations '\r', '\n', '\t', '\'', '\\'. This means, one can either
	 * use <code>setDelimiters("\r\n\t\\");</code> or
	 * <code>setDelimiters("\\r\\n\\t\\\\");</code>.
	 * 
	 * @param value
	 *            Value to assign to delimiters.
	 * @see Utils#unbackQuoteChars(String)
	 */
	public void setDelimiters(String value) {
		m_Delimiters = Utils.unbackQuoteChars(value);
	}

	/**
	 * Returns the tip text for this property
	 * 
	 * @return tip text for this property suitable for displaying in the
	 *         explorer/experimenter gui
	 */
	public String delimitersTipText() {
		return "Set of delimiter characters to use in tokenizing in case stop words are used (\\r, \\n and \\t can be used for carriage-return, line-feed and tab)";
	}

	/**
	 * Returns the tip text for this property.
	 * 
	 * @return tip text for this property suitable for displaying in the
	 *         explorer/experimenter gui
	 */
	public String LowerCaseTokensTipText() {
		return "If the messages are going to be converted to lowercase.";
	}

	/** Specifies which is the classification type */
	public static final Tag[] TAGS_CLASSIFICATION = {
			new Tag(NA, "No adaptation of the model using the test instance"),
			new Tag(A, "Adaptation of the model using the test instance"), };

	/**
	 * Returns the tip text for this property.
	 * 
	 * @return tip text for this property suitable for displaying in the
	 *         explorer/experimenter gui
	 */
	public String ClassificationTypeTipText() {
		return "The type of classification to use:\n  0 -> No adaptation of the model using the test instance\n  1 -> Adaptation of the model using the test instance\n";
	}

	/**
	 * Gets the classification type for the algorithm
	 * 
	 * @return 0 for Cross Entropy 1 for MDL
	 */
	public SelectedTag getClassificationType() {
		return new SelectedTag(m_ClassificationType, TAGS_CLASSIFICATION);
	}

	/**
	 * Sets whether if the word frequencies for a document (instance) should be
	 * normalized or not.
	 * 
	 * @param newType
	 *            the new type.
	 */
	public void setClassificationType(SelectedTag newType) {

		if (newType.getTags() == TAGS_CLASSIFICATION) {
			m_ClassificationType = newType.getSelectedTag().getID();
		}
	}

	/**
	 * Sets the classification type for the algorithm
	 * 
	 * @param newClassifierType
	 *            0 for Cross Entropy 1 for MDL
	 */
	public void setClassificationType(int newClassifierType) {
		this.m_ClassificationType = newClassifierType;
	}

	/**
	 * Returns the tip text for this property.
	 * 
	 * @return tip text for this property suitable for displaying in the
	 *         explorer/experimenter gui
	 */
	public String EstimateProbabilitiesTipText() {
		return "If the predictions are going to be transformed to probabilities or not\n";
	}

	/**
	 * The dataset header for the purposes of printing out a semi-intelligible
	 * model
	 */
	protected Instances m_Instances;

	/**
	 * Generates the classifier.
	 * 
	 * @param instances
	 *            set of instances serving as training data
	 * @throws Exception
	 *             if the classifier has not been generated successfully
	 */
	public void buildClassifier(Instances instances) throws Exception {

		if (m_Debug) {
			System.err.println("Generating classifier...");
		}

		// We check if stopwords are going to be used
		if (getUseStoplist()) {
			if (m_Debug) {
				System.err.println("Loading stopwords");
			}

			stopwords = new Stopwords();
			try {
				if (getStopwords().exists() && !getStopwords().isDirectory())
					stopwords.read(getStopwords());
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		// can classifier handle the data?
		getCapabilities().testWithFail(instances);

		// remove instances with missing class
		m_NumClasses = instances.numClasses();

		// Copy the instances
		m_Instances = new Instances(instances);

		if (m_Debug) {
			System.err
					.println("Initializing the Compression models for each class");
		}

		// We create the array of the Compression models depending on how many
		// classes they
		// are in the data
		compressionModels = new CompressionModel[m_Instances.numClasses()];

		for (int i = 0; i < compressionModels.length; i++) {
			if (m_Debug) {
				System.err
						.println("\tInitializing the Compression models for class: "
								+ (i + 1));
			}
			compressionModels[i] = CompressionModel
					.makeCopy(this.m_compression);
			compressionModels[i].Initialize();
		}

		if (m_Debug) {
			System.err.println("Training the model");
		}
		int z = 0;
		// There have to be only two attributes: the string and the class
		for (Instance i : m_Instances) {

			// If there are more than one String attributes we concatenate them
			String text = "";

			Enumeration enumeration = i.enumerateAttributes();

			// We iterate through the iterators
			while (enumeration.hasMoreElements()) {
				Attribute att = (Attribute) enumeration.nextElement();

				// We check if the attribute is string
				if (att.isString()) {
					// We concate the value of the attribute string
					text += " " + att.value((int) i.value(att)).toString();
				}
			}

			if (getUseStoplist()) {
				text = removeStopWords(text);
			}
			// We check if the Compression model for the classIndex exists,
			// If it doesn't, we create it. Either way, we add the text to the
			// classifier
			int classIndex = (int) i.classValue();
			if (compressionModels[classIndex] == null) {
				compressionModels[classIndex] = CompressionModel
						.makeCopy(this.m_compression);
				compressionModels[classIndex].Initialize();
			}

			// If lowerCaseTokens has been selected we lowercase
			if (this.m_lowerCaseTokens)
				text = text.toLowerCase();

			if (m_Debug) {
				System.err.println("Adding instance number: " + (z + 1));
			}
			compressionModels[classIndex].addMessage(text.trim());
			z++;
		}

		for (CompressionModel cm : this.compressionModels) {
			if (cm instanceof PST) {
				((PST) cm).finishLearning();
			} else if (cm instanceof DECTW) {
				((DECTW) cm).finishLearning();
			}
		}
	}

	/**
	 * The stopwords in case they are used
	 */
	private transient Stopwords stopwords = null;

	/**
	 * A function to remove the stopwords of a given message
	 * 
	 * @param message
	 *            The message to be removed stopwords
	 * @return The filtered message
	 */
	private String removeStopWords(String message) {
		if (m_Debug) {
			System.err.println("Removing stopwords for message: " + message);
		}
		StringTokenizer m_Tokenizer;
		m_Tokenizer = new StringTokenizer(message, getDelimiters());

		String text2 = "";
		// Iterate through tokens, perform stemming, and remove
		// stopwords
		// (if required)
		while (m_Tokenizer.hasMoreElements()) {
			String word = ((String) m_Tokenizer.nextElement()).intern();

			if (this.m_lowerCaseTokens == true)
				word = word.toLowerCase();

			if (!stopwords.is(word)) {
				text2 += " " + word;
			}

		}
		return text2;

	}

	public CompressionTextClassifier() {

	}

	/**
	 * Returns default capabilities of the classifier.
	 * 
	 * @return the capabilities of this classifier
	 */
	public Capabilities getCapabilities() {
		Capabilities result = super.getCapabilities(); // returns the object
														// from
														// weka.classifiers.Classifier

		// attributes
		result.disableAll();
		result.enable(Capability.STRING_ATTRIBUTES);
		result.enable(Capability.MISSING_VALUES);
		result.enable(Capability.BINARY_ATTRIBUTES);

		// class
		result.enable(Capability.NOMINAL_CLASS);
		result.enable(Capability.BINARY_CLASS);

		return result;
	}

	/**
	 * Calculates the class membership probabilities for the given test
	 * instance.
	 * 
	 * @param instance
	 *            the instance to be classified
	 * @return predicted class probability distribution
	 * @throws Exception
	 *             if an error occurred during the prediction
	 */
	public double[] distributionForInstance(Instance instance) throws Exception {

		if (m_Debug) {
			System.err.println("Predicting");
		}

		double[] values = new double[this.compressionModels.length];

		double[] sumInv = new double[this.compressionModels.length];

		// If there are more than one String attributes we concatenate them
		String text = "";

		Enumeration enumeration = instance.enumerateAttributes();

		// We iterate through the iterators
		while (enumeration.hasMoreElements()) {
			Attribute att = (Attribute) enumeration.nextElement();

			// We check if the attribute is string
			if (att.isString()) {
				// We concatenate the value of the attribute string
				text += att.value((int) instance.value(att)).toString() + " ";
			}
		}

		if (getUseStoplist()) {
			text = removeStopWords(text);
		}

		double sum = 0.0;

		// If lowerCaseTokens has been selected we lowercase the message
		if (this.m_lowerCaseTokens)
			text = text.toLowerCase();

		// We calculate the distributions
		double max = 0.0;
		int maxIndex = -1;
		for (int i = 0; i < compressionModels.length; i++) {
			double value = 0.0;
			try {
				value = this.m_ClassificationType == 0 ? this.compressionModels[i]
						.evaluationWithNoAdaption(text)
						: this.compressionModels[i]
								.evaluationWithAdaption(text);
				value = (Double.isInfinite(value) || Double.isNaN(value)) ? (values[i] = 0)
						: (values[i] = (1 / value));

				// If we do not have to estimate probabilities argmax of the
				// inverse is used
				if (!this.m_estimateProbabilities) {
					if (max < value) {
						max = value;
						maxIndex = i;
					}
				} else
					sum += value;
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		// If we do not have to estimate probabilities argmax of the inverse is
		// used
		if (this.m_estimateProbabilities) {
			for (int i = 0; i < compressionModels.length; i++) {
				values[i] /= sum;
			}
		} else {
			for (int i = 0; i < compressionModels.length; i++) {
				if (i == maxIndex) {
					values[i] = 1.0;
				} else {
					values[i] = 0.0;
				}
			}

		}

		if (m_Debug) {
			System.err.println("Predicted");
		}

		return values;
	}

	/**
	 * Returns an enumeration describing the available options.
	 * 
	 * @return an enumeration of all the available options.
	 */
	public Enumeration listOptions() {

		Vector newVector = new Vector(1);

		newVector.addElement(new Option("\tSelect the classifier type"
				+ "\n0 -> No Model Adaptation with Test\n"
				+ "\n1 -> Model Adaptation with Test", "C", 0, "-C"));

		newVector
				.addElement(new Option(
						"\tSelect if the messages are going to be converted to lowercase. ",
						"L", 0, "-L"));

		newVector.addElement(new Option("\tThe Compresion model to use.\n"
				+ "\t(default: weka.compression.models.DMCCompressor)", "M", 1,
				"-M <classname and parameters>"));

		newVector.addElement(new Option("", "", 0,
				"\nOptions specific to kernel "
						+ getCompressionModel().getClass().getName() + ":"));

		Enumeration enm = ((OptionHandler) getCompressionModel()).listOptions();
		while (enm.hasMoreElements())
			newVector.addElement(enm.nextElement());

		newVector
				.addElement(new Option(
						"\tSelect if the predictions are going to be transformed to probabilities or not. ",
						"P", 0, "-P"));

		newVector
				.addElement(new Option(
						"\tA file containing stopwords to override the default ones.\n"
								+ "\tUsing this option automatically sets the flag ('-S') to use the\n"
								+ "\tstoplist if the file exists.\n"
								+ "\tFormat: one stopword per line, lines starting with '#'\n"
								+ "\tare interpreted as comments and ignored.",
						"stopwords", 1, "-stopwords <file>"));

		newVector.addElement(new Option(
				"\tThe delimiters to use in case stop words are used\n"
						+ "\t(default ' \\r\\n\\t.,;:'\"()?!').", "delimiters",
				1, "-delimiters <value>"));

		newVector.addElement(new Option(
				"\tIgnore words that are in the stoplist.", "S", 0, "-S"));

		return newVector.elements();
	}

	/**
	 * Parses a given list of options.
	 * <p/>
	 * 
	 * <!-- options-start --> Valid options are:
	 * <p/>
	 * 
	 * <pre>
	 * -C
	 *  Classification method (0 for Cross Entropy, 1 for MDL)
	 *  (use when k &gt; 1)
	 * </pre>
	 * 
	 * *
	 * 
	 * <pre>
	 * -delimiters &lt;String&gt;
	 * \tThe delimiters to use\n"
	 * 	+ "\t(default ' \\r\\n\\t.,;:'\"()?!').",
	 *         "delimiters", 1, "-delimiters
	 * </pre>
	 * 
	 * <pre>
	 * -P 
	 * If the predictions are going to be transformed to probabilities or not
	 * </pre>
	 * 
	 * *
	 * 
	 * <pre>
	 * -L 
	 * If the messages are going to be converted to lowercase
	 * </pre>
	 * 
	 * * </pre>
	 * 
	 * 
	 * <pre>
	 * -S
	 *  Ignore words that are in the stoplist.
	 * </pre>
	 * 
	 * <pre>
	 * -stopwords &lt;file&gt;
	 *  A file containing stopwords to override the default ones.
	 *  Using this option automatically sets the flag ('-S') to use the
	 *  stoplist if the file exists.
	 *  Format: one stopword per line, lines starting with '#'
	 *  are interpreted as comments and ignored.
	 * </pre>
	 * 
	 * 
	 * <!-- options-end -->
	 * 
	 * @param options
	 *            the list of options as an array of strings
	 * @throws Exception
	 *             if an option is not supported
	 */
	public void setOptions(String[] options) throws Exception {

		String classificationTypeText = Utils.getOption('C', options);
		if (classificationTypeText.length() != 0) {
			setClassificationType(Integer.parseInt(classificationTypeText));
		}

		setLowerCaseTokens(Utils.getFlag('L', options));
		Utils.checkForRemainingOptions(options);

		String tmpStr = Utils.getOption('M', options);
		String[] tmpOptions = Utils.splitOptions(tmpStr);
		if (tmpOptions.length != 0) {
			tmpStr = tmpOptions[0];
			tmpOptions[0] = "";
			setCompressionModel(CompressionModel.forName(tmpStr, tmpOptions));
		}

		tmpStr = Utils.getOption('M', options);
		tmpOptions = Utils.splitOptions(tmpStr);
		if (tmpOptions.length != 0) {
			tmpStr = tmpOptions[0];
			tmpOptions[0] = "";
			setCompressionModel(CompressionModel.forName(tmpStr, tmpOptions));
		}

		setEstimateProbabilities(Utils.getFlag('P', options));

		setUseStoplist(Utils.getFlag('S', options));

		String value = Utils.getOption("stopwords", options);
		if (value.length() != 0)
			setStopwords(new File(value));
		else
			setStopwords(null);

		tmpStr = Utils.getOption("delimiters", options);
		if (tmpStr.length() != 0)
			setDelimiters(tmpStr);
		else
			setDelimiters(" \r\n\t.,;:'\"()?!");

		Utils.checkForRemainingOptions(options);
	}

	/**
	 * Gets the current settings
	 * 
	 * @return an array of strings suitable for passing to setOptions()
	 */
	public String[] getOptions() {

		Vector result;

		String[] options;
		result = new Vector();
		options = super.getOptions();

		for (int i = 0; i < options.length; i++)
			result.add(options[i]);

		result.add("-C");
		result.add(this.m_ClassificationType);

		if (getLowerCaseTokens()) {
			result.add("-L");
		}

		result.add("-K");
		result.add("" + getCompressionModel().getClass().getName() + " "
				+ Utils.joinOptions(getCompressionModel().getOptions()));

		if (getEstimateProbabilities()) {
			result.add("-P");
		}

		if (getUseStoplist())
			result.add("-S");

		if (!getStopwords().isDirectory()) {
			result.add("-stopwords");
			result.add(getStopwords().getAbsolutePath());
		}

		result.add("-delimiters");
		result.add(getDelimiters());

		String[] options2 = new String[result.size()];

		int i = 0;
		for (Object o : result) {
			options2[i] = result.get(i).toString();
			i++;
		}
		return options2;

	}

	/**
	 * Returns a description of this classifier.
	 * 
	 * @return a description of this classifier as a string.
	 */
	public String toString() {

		String result = "Compression text classifier\n using:";
		result += (m_useStoplist) ? "\n\tStopwords file: " + getStopwords()
				: "\n\tNo stopwords";
		result += (m_estimateProbabilities) ? "\n\tEstimate probabilities"
				: "\n\tNo estimation of probabilites";
		result += (m_lowerCaseTokens) ? "\n\tTokens are going to be converted to lower"
				: "\n\tOriginal tokens";
		result += "\n\tClassification Type: "
				+ (this.m_ClassificationType == 0 ? "No adaptation"
						: "Adaptation");
		result += "\n\tCompression Model: "
				+ this.m_compression.getClass().toString();

		return result;
	}

	/**
	 * Returns the revision string.
	 * 
	 * @return the revision
	 */
	public String getRevision() {
		return RevisionUtils.extract("$Revision: 1 $");
	}

	/**
	 * Main method for testing this class.
	 * 
	 * @param argv
	 *            should contain command line options (see setOptions)
	 */
	public static void main(String[] argv) {
		runClassifier(new CompressionTextClassifier(), argv);
	}
}
