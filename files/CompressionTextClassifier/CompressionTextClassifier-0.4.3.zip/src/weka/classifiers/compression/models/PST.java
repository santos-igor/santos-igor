package weka.classifiers.compression.models;

import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.util.Enumeration;
import java.util.Vector;
import weka.classifiers.compression.vmm.algs.PSTPredictor;
import weka.core.CapabilitiesHandler;
import weka.core.Option;
import weka.core.OptionHandler;
import weka.core.RevisionHandler;
import weka.core.TechnicalInformation;
import weka.core.Utils;
import weka.core.TechnicalInformation.Field;
import weka.core.TechnicalInformation.Type;

/** 
 * A wrapper for PST: Probabilistic Suffix Trees Compressor to use in the
 * CompressionTexClassifier
 * 
 * @author Igor Santos (isantos@deusto.es)
 * @version $Revision: 1 $
 */
public class PST extends CompressionModel implements Cloneable, Serializable,
		OptionHandler, CapabilitiesHandler, RevisionHandler {

	
	private static final long serialVersionUID = 8691804482725884482L;
	
	/* The alphabet size */
	private int abSize = 256;

	/**
	 * Gets the alphabet size
	 * 
	 * @return the alphabet size
	 */
	public int getAbSize() {
		return abSize;
	}

	/**
	 * Sets the alphabet size
	 * 
	 * @param abSize
	 *            the new value
	 */
	public void setAbSize(int abSize) {
		this.abSize = abSize;
	}

	public String abSizeTipText() {
		return "Changes the alphabet size";
	}

	/* The Variable Markov Model Order */
	private int vmmOrder = 2;

	/**
	 * Gets the Variable Markov Model Order
	 * 
	 * @return the Variable Markov Model Order
	 */
	public int getVmmOrder() {
		return vmmOrder;
	}

	/**
	 * Sets the Variable Markov Model Order
	 * 
	 * @param abSizethe
	 *            Variable Markov Model Order
	 */
	public void setVmmOrder(int vmmOrder) {
		this.vmmOrder = vmmOrder;
	}

	public String vmmOrderTipText() {
		return "Changes the aVariable Markov Model Order";
	}

	private double pMin = 0.001;

	public double getpMin() {
		return pMin;
	}

	public void setpMin(double pMin) {
		this.pMin = pMin;
	}

	public String pMinTipText() {
		return "Sets the pMin value";
	}

	public double getAlpha() {
		return alpha;
	}

	public void setAlpha(double alpha) {
		this.alpha = alpha;
	}

	public String alphaTipText() {
		return "Sets the Alpha value";
	}

	public double getGamma() {
		return gamma;
	}

	public void setGamma(double gamma) {
		this.gamma = gamma;
	}

	public String gammaTipText() {
		return "Sets the Gamma value";
	}

	public double getR() {
		return r;
	}

	public void setR(double r) {
		this.r = r;
	}

	public String rTipText() {
		return "Sets the r value";
	}

	private double alpha = 0.0;
	private double gamma = 0.0001;
	private double r = 1.05;

	public void Initialize() {
		this.ppstp = new PSTPredictor();
		this.ppstp.init(abSize, pMin, alpha, gamma, r, vmmOrder);
	}

	private PSTPredictor ppstp;

	public void addMessage(String message) {
		String newString = "";
		try {
			newString = new String(message.getBytes("ISO-8859-1"));
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		this.ppstp.learn(newString);
	}

	public void finishLearning() {
		this.ppstp.finish();
	}

	public double evaluationWithNoAdaption(String message) {
		String newString = "";
		try {
			newString = new String(message.getBytes("ISO-8859-1"));
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		return this.ppstp.crossEntropy(newString);
	}

	public double evaluationWithAdaption(String message) {
		
		String newString = "";
		try {
			newString = new String(message.getBytes("ISO-8859-1"));
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return this.ppstp.logEvalAdapt(newString);
	}

	public String globalInfo() {

		return "Probabilistic Su�x Trees (PST) Compressor for Text Classification, see\n\n"
				+ getTechnicalInformation().toString();
	}

	/**
	 * Returns an instance of a TechnicalInformation object, containing detailed
	 * information about the technical background of this class, e.g., paper
	 * reference or book this class is based on.
	 * 
	 * @return the technical information about this class
	 */
	public TechnicalInformation getTechnicalInformation() {
		TechnicalInformation result;

		result = new TechnicalInformation(Type.ARTICLE);
		result.setValue(Field.AUTHOR,
				"Ron Begleiter and Ran El-Yaniv and Golan Yona");
		result.setValue(Field.YEAR, "2004");
		result.setValue(Field.TITLE,
				"On Prediction Using Variable Order Markov Models");
		result.setValue(Field.JOURNAL,
				"Journal of Artificial Intelligence Research (JAIR)");
		result.setValue(Field.VOLUME, "22");
		result.setValue(Field.PAGES, "385-421");

		return result;
	}

	public String[] getOptions() {

		Vector result;

		String[] options;
		result = new Vector();
		options = super.getOptions();

		for (int i = 0; i < options.length; i++)
			result.add(options[i]);

		result.add("-A");
		result.add(this.abSize);

		result.add("-L");
		result.add(this.alpha);

		result.add("-G");
		result.add(this.gamma);

		result.add("-R");
		result.add(this.r);

		result.add("-P");
		result.add(this.pMin);

		result.add("-O");
		result.add(this.vmmOrder);

		String[] options2 = new String[result.size()];

		int i = 0;
		for (Object o : result) {
			options2[i] = result.get(i).toString();
			i++;
		}
		return options2;

	}

	public void setOptions(String[] options) throws Exception {

		String abSizeText = Utils.getOption('A', options);
		if (abSizeText.length() != 0) {
			setAbSize(Integer.parseInt(abSizeText));
		}

		String vmmOrderText = Utils.getOption('O', options);
		if (vmmOrderText.length() != 0) {
			setVmmOrder(Integer.parseInt(vmmOrderText));
		}

		String alphaText = Utils.getOption('L', options);
		if (alphaText.length() != 0) {
			setAlpha(Integer.parseInt(alphaText));
		}

		String gammaText = Utils.getOption('G', options);
		if (gammaText.length() != 0) {
			setGamma(Double.parseDouble(gammaText));
		}

		String rText = Utils.getOption('R', options);
		if (rText.length() != 0) {
			setR(Double.parseDouble(rText));
		}

		String pMinttext = Utils.getOption('P', options);
		if (pMinttext.length() != 0) {
			setpMin(Double.parseDouble(pMinttext));
		}

		Utils.checkForRemainingOptions(options);
	}

	/**
	 * Returns an enumeration describing the available options.
	 * 
	 * @return an enumeration of all the available options.
	 */
	public Enumeration listOptions() {

		Vector newVector = new Vector(1);

		newVector.addElement(new Option(
				"\tSelect the size of the source alphabet", "A", 0, "-A"));

		newVector
				.addElement(new Option(
						"\tSelect the order of the Variable Markov Order", "O",
						0, "-O"));

		newVector.addElement(new Option("\tSelect the value of Alpha", "O", 0,
				"-L"));

		newVector.addElement(new Option("\tSelect the value of pMin", "O", 0,
				"-P"));

		newVector
				.addElement(new Option("\tSelect the value of r", "O", 0, "-R"));

		newVector.addElement(new Option("\tSelect the value of Gamma", "O", 0,
				"-G"));

		return newVector.elements();
	}

}
