package weka.classifiers.compression.models;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import weka.classifiers.compression.dmc.Node;
import weka.core.Capabilities;
import weka.core.CapabilitiesHandler;
import weka.core.OptionHandler;
import weka.core.RevisionHandler;
import weka.core.TechnicalInformation;
import weka.core.TechnicalInformation.Field;
import weka.core.TechnicalInformation.Type;

/**
 * A DMC-based text classifier for the Markov Chain Compression Model ported of
 * the DMC.c version by G. Cormack to use in the CompressionTexClassifier
 * 
 * @author Igor Santos (isantos@deusto.es)
 * @author Aitor Santamaria-Ibirika (a.santamaria@deusto.es)
 * @version $Revision: 1 $
 */

public class DMC extends CompressionModel implements Cloneable, Serializable,
		OptionHandler, CapabilitiesHandler, RevisionHandler {

	private static final long serialVersionUID = 1L;

	private static int THRESHOLD = 2;

	private static int BIG_THRESHOLD = 2;

	private String data = "";
	private int dataNext = 0;
	private boolean dataEnd = false;

	private int p = -1;
	private int z = -1;
	private int[][] nodes = null;

	private List<Node> lNodes = new ArrayList<Node>();

	public void addMessage(String message) {
		data = message;
		dataNext = 0;
		dataEnd = false;
		comp();
	}

	public void Initialize() {
		pflush();
	}

	public double evaluationWithNoAdaption(String message) {
		data = message;
		dataNext = 0;
		dataEnd = false;
		int c;
		int i;
		int bit;
		int count = 0;

		double result = 0;

		preset();

		for (;;) {
			c = getNext();
			if (dataEnd) {
				break;
			}

			for (i = 0; i < 8; i++) {
				count++;
				bit = (c << i) & 0x80;
				float probZero = predict();
				double value = ((Math.log10(((bit == 0) ? probZero
						: 1 - probZero)) / Math.log10(2)));
				if (!Double.isInfinite(value) && !Double.isNaN(value)) {
					result += value;
				}
				p = lNodes.get(p).getNext()[bit != 0 ? 1 : 0];
			}
		}
		return -result / count;
	}

	public double evaluationWithAdaption(String message) {
		DMC copyModel = null;
		try {
			copyModel = (DMC) this.clone();
		} catch (CloneNotSupportedException e) {
			e.printStackTrace();
		}

		copyModel.data = message;
		copyModel.dataNext = 0;
		copyModel.dataEnd = false;
		int c;
		int i;
		int bit;
		int count = 0;

		double result = 0;

		copyModel.preset();

		for (;;) {
			c = copyModel.getNext();
			if (copyModel.dataEnd) {
				break;
			}

			for (i = 0; i < 8; i++) {
				count++;
				bit = (c << i) & 0x80;
				float probZero = copyModel.predict();
				copyModel.pupdate(bit != 0 ? 1 : 0);
				double value = ((Math.log10(((bit == 0) ? probZero
						: 1 - probZero)) / Math.log10(2)));
				if (!Double.isInfinite(value) && !Double.isNaN(value)) {
					result += value;
				}

			}
		}

		return -result / count;
	}

	// Private methods

	private void pflush() {
		nodes = new int[256][256];

		for (int i = 0; i < 256; i++)
			for (int j = 0; j < 256; j++) {
				Node newNode = new Node();
				nodes[i][j] = lNodes.size();
				lNodes.add(newNode);
			}
		for (int j = 0; j < 256; j++) {
			for (int i = 0; i < 127; i++) {
				lNodes.get(nodes[j][i]).getCount()[0] = 0.2f;
				lNodes.get(nodes[j][i]).getCount()[1] = 0.2f;
				lNodes.get(nodes[j][i]).getNext()[0] = nodes[j][2 * i + 1];
				lNodes.get(nodes[j][i]).getNext()[1] = nodes[j][2 * i + 2];
			}

			for (int i = 127; i < 255; i++) {

				lNodes.get(nodes[j][i]).getCount()[0] = 0.2f;
				lNodes.get(nodes[j][i]).getCount()[1] = 0.2f;

				lNodes.get(nodes[j][i]).getNext()[0] = nodes[i + 1][0];
				lNodes.get(nodes[j][i]).getNext()[1] = nodes[i - 127][0];
			}
		}

		preset();
	}

	private void preset() {
		p = nodes[0][0];
	}

	private float predict() {
		return lNodes.get(p).getCount()[0]
				/ (lNodes.get(p).getCount()[0] + lNodes.get(p).getCount()[1]);
	}

	private void pupdate(int b) {
		float r;

		if (lNodes.get(p).getCount()[b] >= THRESHOLD
				&& lNodes.get(lNodes.get(p).getNext()[b]).getCount()[0]

				+ lNodes.get(lNodes.get(p).getNext()[b]).getCount()[1] >= BIG_THRESHOLD
						+ lNodes.get(p).getCount()[b]) {
			Node newNode = new Node();
			z = lNodes.size();
			lNodes.add(newNode);
			r = lNodes.get(p).getCount()[b]
					/ (lNodes.get(lNodes.get(p).getNext()[b]).getCount()[1] + lNodes
							.get(lNodes.get(p).getNext()[b]).getCount()[0]);

			lNodes.get(z).getCount()[0] = lNodes
					.get(lNodes.get(p).getNext()[b]).getCount()[0] * r;
			lNodes.get(lNodes.get(p).getNext()[b]).getCount()[0] -= lNodes.get(
					z).getCount()[0];

			lNodes.get(z).getCount()[1] = lNodes
					.get(lNodes.get(p).getNext()[b]).getCount()[1] * r;
			lNodes.get(lNodes.get(p).getNext()[b]).getCount()[1] -= lNodes.get(
					z).getCount()[1];
			lNodes.get(z).getNext()[0] = lNodes.get(lNodes.get(p).getNext()[b])
					.getNext()[0];
			lNodes.get(z).getNext()[1] = lNodes.get(lNodes.get(p).getNext()[b])
					.getNext()[1];
			lNodes.get(p).getNext()[b] = z;

		}

		lNodes.get(p).getCount()[b]++;
		p = lNodes.get(p).getNext()[b];
	}

	private void comp() {
		int max = 0x1000000;
		int min = 0;
		int mid;
		int c;
		int i;
		int inbytes = 0;
		int outbytes = 3;
		int pout = 3;
		int bit;

		for (;;) {
			c = getNext();
			if (dataEnd) {
				min = max - 1;
				// "Compress done: bytes in {0}, bytes out {1}, ratio {2}",
				// inbytes, outbytes, (float)outbytes / inbytes
				break;
			}

			for (i = 0; i < 8; i++) {
				bit = (c << i) & 0x80;
				mid = (int) (min + (max - min - 1) * predict());

				pupdate(bit != 0 ? 1 : 0);

				if (mid == min) {
					mid++;
				}

				if (mid == (max - 1)) {
					mid--;
				}

				if (bit != 0) {
					min = mid;
				} else {
					max = mid;
				}

				while ((max - min) < 256) {
					if (bit != 0) {
						max--;
					}

					outbytes++;
					min = (min << 8) & 0xFFFF00;
					max = (max << 8) & 0xFFFF00;

					if (min >= max) {
						max = 0x1000000;
					}
				}
			}

			if ((++inbytes & 0xFF) == 0) {
				if ((inbytes & 0xFFFF) == 0) {
					// "Compressing... bytes in %d, bytes out %d, ratio %f",
					// inbytes, outbytes, (float)outbytes / inbytes;
				}

				if (outbytes - pout > 256) {
					// "Compressing failing";
					pflush();
				}

				pout = outbytes;
			}
		}
	}

	private char getNext() {
		if (data.length() > dataNext) {
			char NextChar = data.charAt(dataNext);
			dataNext++;
			return NextChar;
		} else {
			dataEnd = true;
			return ' ';
		}
	}

	public String globalInfo() {

		return "DMC: Dynamic Markov Chain Compressor for Text Classification. "
				+ "For more information, see\n\n"
				+ getTechnicalInformation().toString();
	}

	/**
	 * Returns an instance of a TechnicalInformation object, containing detailed
	 * information about the technical background of this class, e.g., paper
	 * reference or book this class is based on.
	 * 
	 * @return the technical information about this class
	 */
	public TechnicalInformation getTechnicalInformation() {
		TechnicalInformation result;

		result = new TechnicalInformation(Type.ARTICLE);
		result.setValue(Field.AUTHOR, "GV Cormack and RNS Horspool");
		result.setValue(Field.YEAR, "1987");
		result.setValue(Field.TITLE,
				"Data compression using dynamic Markov modelling");
		result.setValue(Field.JOURNAL, "The Computer Journal");
		result.setValue(Field.VOLUME, "30");
		result.setValue(Field.NUMBER, "6");
		result.setValue(Field.PAGES, "541-550");

		return result;
	}

}
