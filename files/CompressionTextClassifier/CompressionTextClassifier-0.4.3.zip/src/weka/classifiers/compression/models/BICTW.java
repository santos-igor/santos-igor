package weka.classifiers.compression.models;

import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.util.Enumeration;
import java.util.Vector;

import weka.classifiers.compression.vmm.algs.BinaryCTWPredictor;
import weka.core.CapabilitiesHandler;
import weka.core.Option;
import weka.core.OptionHandler;
import weka.core.RevisionHandler;
import weka.core.TechnicalInformation;
import weka.core.Utils;
import weka.core.TechnicalInformation.Field;
import weka.core.TechnicalInformation.Type;

/**
 * A wrapper for Binary CTW Compressor to use in the CompressionTexClassifier
 * 
 * @author Igor Santos (isantos@deusto.es)
 * @version $Revision: 1 $
 */

public class BICTW extends CompressionModel implements Cloneable, Serializable,
		OptionHandler, CapabilitiesHandler, RevisionHandler {

	private static final long serialVersionUID = -466022901344014268L;

	/* The alphabet size */
	private int abSize = 256;

	/**
	 * Gets the alphabet size
	 * 
	 * @return the alphabet size
	 */
	public int getAbSize() {
		return abSize;
	}

	/**
	 * Sets the alphabet size
	 * 
	 * @param abSize
	 *            the new value
	 */
	public void setAbSize(int abSize) {
		this.abSize = abSize;
	}

	public String abSizeTipText() {
		return "Changes the alphabet size";
	}

	private int vmmOrder = 2;

	public int getVmmOrder() {
		return vmmOrder;
	}

	public void setVmmOrder(int mParam) {
		this.vmmOrder = mParam;
	}

	public String vmmOrderTipText() {
		return "Changes the variable markov model order";
	}

	private BinaryCTWPredictor bctw;

	public void Initialize() {
		this.bctw = new BinaryCTWPredictor();
		this.bctw.init(abSize, vmmOrder);
	}

	public void addMessage(String message) {

		String newString = "";
		try {
			newString = new String(message.getBytes("ISO-8859-1"));
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		this.bctw.learn(newString);
	}

	public double evaluationWithNoAdaption(String message) {

		String newString = "";
		try {
			newString = new String(message.getBytes("ISO-8859-1"));
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return this.bctw.logEval(newString);
	}

	public double evaluationWithAdaption(String message) {

		BICTW copy = null;
		try {
			copy = (BICTW)BICTW.makeCopy(this);
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		String newString = "";
		try {
			newString = new String(message.getBytes("ISO-8859-1"));
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return copy.bctw.logEvalAdapt(newString);
	}

	public String globalInfo() {

		return "BICTW: Binary Context Tree Weighting Method (CTW) for Multi-Alphabets Compressor for Text Classification, see\n\n"
				+ getTechnicalInformation().toString();
	}

	/**
	 * Returns an instance of a TechnicalInformation object, containing detailed
	 * information about the technical background of this class, e.g., paper
	 * reference or book this class is based on.
	 * 
	 * @return the technical information about this class
	 */
	public TechnicalInformation getTechnicalInformation() {
		TechnicalInformation result;

		result = new TechnicalInformation(Type.ARTICLE);
		result.setValue(Field.AUTHOR,
				"Ron Begleiter and Ran El-Yaniv and Golan Yona");
		result.setValue(Field.YEAR, "2004");
		result.setValue(Field.TITLE,
				"On Prediction Using Variable Order Markov Models");
		result.setValue(Field.JOURNAL,
				"Journal of Artificial Intelligence Research (JAIR)");
		result.setValue(Field.VOLUME, "22");
		result.setValue(Field.PAGES, "385-421");

		return result;
	}

	public String[] getOptions() {

		Vector result;

		String[] options;
		result = new Vector();
		options = super.getOptions();

		for (int i = 0; i < options.length; i++)
			result.add(options[i]);

		result.add("-A");
		result.add(this.abSize);

		result.add("-O");
		result.add(this.vmmOrder);

		String[] options2 = new String[result.size()];

		int i = 0;
		for (Object o : result) {
			options2[i] = result.get(i).toString();
			i++;
		}
		return options2;

	}

	public void setOptions(String[] options) throws Exception {

		String abSizeText = Utils.getOption('A', options);
		if (abSizeText.length() != 0) {
			setAbSize(Integer.parseInt(abSizeText));
		}

		String vmmOrderText = Utils.getOption('O', options);
		if (vmmOrderText.length() != 0) {
			setVmmOrder(Integer.parseInt(vmmOrderText));
		}

		Utils.checkForRemainingOptions(options);
	}

	/**
	 * Returns an enumeration describing the available options.
	 * 
	 * @return an enumeration of all the available options.
	 */
	public Enumeration listOptions() {

		Vector newVector = new Vector(1);

		newVector.addElement(new Option(
				"\tSelect the size of the source alphabet", "A", 0, "-A"));

		newVector
				.addElement(new Option(
						"\tSelect the order of the Variable Markov Order", "O",
						0, "-O"));

		return newVector.elements();
	}
}
