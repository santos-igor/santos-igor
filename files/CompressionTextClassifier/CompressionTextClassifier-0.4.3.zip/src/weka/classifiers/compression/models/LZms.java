package weka.classifiers.compression.models;

import java.io.File;
import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.Vector;

import weka.classifiers.compression.dmc.Node;
import weka.classifiers.compression.vmm.algs.LZmsPredictor;
import weka.classifiers.compression.vmm.algs.PPMCPredictor;
import weka.core.Capabilities;
import weka.core.CapabilitiesHandler;
import weka.core.Option;
import weka.core.OptionHandler;
import weka.core.RevisionHandler;
import weka.core.TechnicalInformation;
import weka.core.Utils;
import weka.core.TechnicalInformation.Field;
import weka.core.TechnicalInformation.Type;

/**
 * A wrapper for LZ-MS: An Improved Lempel-Ziv Algorithm Compressor to use in
 * the CompressionTexClassifier
 * 
 * @author Igor Santos (isantos@deusto.es)
 * @version $Revision: 1 $
 */

public class LZms extends CompressionModel implements Cloneable, Serializable,
		OptionHandler, CapabilitiesHandler, RevisionHandler {

	private static final long serialVersionUID = -466022901344014268L;

	/* The alphabet size */
	private int abSize = 256;

	/**
	 * Gets the alphabet size
	 * 
	 * @return the alphabet size
	 */
	public int getAbSize() {
		return abSize;
	}

	/**
	 * Sets the alphabet size
	 * 
	 * @param abSize
	 *            the new value
	 */
	public void setAbSize(int abSize) {
		this.abSize = abSize;
	}

	public String abSizeTipText() {
		return "Changes the alphabet size";
	}

	private int mParam = 2;

	public int getmParam() {
		return mParam;
	}

	public void setmParam(int mParam) {
		this.mParam = mParam;
	}

	public String mParamTipText() {
		return "Changes the parameter \"m\"";
	}

	public int getsParam() {
		return sParam;
	}

	public void setsParam(int sParam) {
		this.sParam = sParam;
	}

	public String sParamTipText() {
		return "Changes the parameter \"s\"";
	}

	private int sParam = 0;

	private LZmsPredictor lmz;

	public void Initialize() {
		this.lmz = new LZmsPredictor();
		this.lmz.init(abSize, mParam, sParam);
	}

	public void addMessage(String message) {
		this.lmz.learn(message);
	}

	public double evaluationWithNoAdaption(String message) {
		return this.lmz.logEval(message);
	}

	public double evaluationWithAdaption(String message) {
		String newString = "";
		try {
			newString = new String(message.getBytes("ISO-8859-1"));
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		LZms copy = null;
		try {
			copy = (LZms)LZms.makeCopy(this);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return copy.lmz.logEval(newString, newString);
	}

	public String globalInfo() {

		return "LZ-MS: An Improved Lempel-Ziv Algorithm Compressor for Text Classification, see\n\n"
				+ getTechnicalInformation().toString();
	}

	/**
	 * Returns an instance of a TechnicalInformation object, containing detailed
	 * information about the technical background of this class, e.g., paper
	 * reference or book this class is based on.
	 * 
	 * @return the technical information about this class
	 */
	public TechnicalInformation getTechnicalInformation() {
		TechnicalInformation result;

		result = new TechnicalInformation(Type.ARTICLE);
		result.setValue(Field.AUTHOR,
				"Ron Begleiter and Ran El-Yaniv and Golan Yona");
		result.setValue(Field.YEAR, "2004");
		result.setValue(Field.TITLE,
				"On Prediction Using Variable Order Markov Models");
		result.setValue(Field.JOURNAL,
				"Journal of Artificial Intelligence Research (JAIR)");
		result.setValue(Field.VOLUME, "22");
		result.setValue(Field.PAGES, "385-421");

		return result;
	}

	public String[] getOptions() {

		Vector result;

		String[] options;
		result = new Vector();
		options = super.getOptions();

		for (int i = 0; i < options.length; i++)
			result.add(options[i]);

		result.add("-A");
		result.add(this.abSize);

		result.add("-M");
		result.add(this.mParam);

		result.add("-S");
		result.add(this.sParam);

		String[] options2 = new String[result.size()];

		int i = 0;
		for (Object o : result) {
			options2[i] = result.get(i).toString();
			i++;
		}
		return options2;

	}

	public void setOptions(String[] options) throws Exception {

		String abSizeText = Utils.getOption('A', options);
		if (abSizeText.length() != 0) {
			setAbSize(Integer.parseInt(abSizeText));
		}

		String mParamText = Utils.getOption('M', options);
		if (mParamText.length() != 0) {
			setmParam(Integer.parseInt(mParamText));
		}

		String sParamText = Utils.getOption('S', options);
		if (mParamText.length() != 0) {
			setmParam(Integer.parseInt(sParamText));
		}

		Utils.checkForRemainingOptions(options);
	}

	/**
	 * Returns an enumeration describing the available options.
	 * 
	 * @return an enumeration of all the available options.
	 */
	public Enumeration listOptions() {

		Vector newVector = new Vector(1);

		newVector.addElement(new Option(
				"\tSelect the size of the source alphabet", "A", 0, "-A"));

		newVector.addElement(new Option("\tSelect the value of M parameter",
				"M", 0, "-M"));

		newVector.addElement(new Option("\tSelect the value of S parameter",
				"S", 0, "-S"));

		return newVector.elements();
	}

}
