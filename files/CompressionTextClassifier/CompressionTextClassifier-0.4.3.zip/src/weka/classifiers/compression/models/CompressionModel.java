/*
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
 *    CompressionTextClassifier.java
 */
package weka.classifiers.compression.models;

import java.io.Serializable;
import java.util.Enumeration;
import java.util.Vector;
import weka.core.Capabilities;
import weka.core.CapabilitiesHandler;
import weka.core.Option;
import weka.core.OptionHandler;
import weka.core.RevisionHandler;
import weka.core.RevisionUtils;
import weka.core.SerializedObject;
import weka.core.Utils;

public abstract class CompressionModel implements Cloneable, Serializable,
		OptionHandler, CapabilitiesHandler, RevisionHandler {

	private static final long serialVersionUID = -3967631572556579036L;

	/** enables debugging output */
	protected boolean m_Debug = false;

	/**
	 * Returns a string describing the Compression model
	 * 
	 * @return a description suitable for displaying in the
	 *         explorer/experimenter gui
	 */
	public abstract String globalInfo();

	public abstract void addMessage(String message);

	public abstract double evaluationWithNoAdaption(String message);

	public abstract double evaluationWithAdaption(String message);

	public abstract void Initialize();

	/**
	 * Returns an enumeration describing the available options.
	 * 
	 * @return an enumeration of all the available options.
	 */
	public Enumeration listOptions() {
		Vector result;

		result = new Vector();

		result.addElement(new Option(
				"\tEnables debugging output (if available) to be printed.\n"
						+ "\t(default: off)", "D", 0, "-D"));
		return result.elements();
	}

	/**
	 * Parses a given list of options.
	 * <p/>
	 * 
	 * @param options
	 *            the list of options as an array of strings
	 * @throws Exception
	 *             if an option is not supported
	 */
	public void setOptions(String[] options) throws Exception {
		setDebug(Utils.getFlag('D', options));

		Utils.checkForRemainingOptions(options);
	}

	/**
	 * Gets the current settings of the compression model.
	 * 
	 * @return an array of strings suitable for passing to setOptions
	 */
	public String[] getOptions() {
		Vector result;

		result = new Vector();

		if (getDebug())
			result.add("-D");

		return (String[]) result.toArray(new String[result.size()]);
	}

	/**
	 * Enables or disables the output of debug information (if the derived
	 * compression model supports that)
	 * 
	 * @param value
	 *            whether to output debugging information
	 */
	public void setDebug(boolean value) {
		m_Debug = value;
	}

	/**
	 * Gets whether debugging output is turned on or not.
	 * 
	 * @return true if debugging output is produced.
	 */
	public boolean getDebug() {
		return m_Debug;
	}

	/**
	 * Returns the tip text for this property
	 * 
	 * @return tip text for this property suitable for displaying in the
	 *         explorer/experimenter gui
	 */
	public String debugTipText() {
		return "Turns on the output of debugging information.";
	}

	/**
	 * Returns the Capabilities of this compression model. Derived compression
	 * models have to override this method to enable capabilities.
	 * 
	 * @return the capabilities of this object
	 * @see Capabilities
	 */
	public Capabilities getCapabilities() {
		Capabilities result = new Capabilities(this);
		result.enableAll();

		return result;
	}

	/**
	 * Returns the revision string.
	 * 
	 * @return the revision
	 */
	public String getRevision() {
		return RevisionUtils.extract("$Revision: 8034 $");
	}

	/**
	 * Creates a deep copy of the given compression model using serialization.
	 * 
	 * @param model
	 *            the compression model to copy
	 * @return a deep copy of the compression model
	 * @throws Exception
	 *             if an error occurs
	 */
	public static CompressionModel makeCopy(CompressionModel model)
			throws Exception {
		return (CompressionModel) new SerializedObject(model).getObject();
	}

	/**
	 * Creates a given number of deep copies of the given compression model
	 * using serialization.
	 * 
	 * @param model
	 *            the compression model to copy
	 * @param num
	 *            the number of compression model copies to create.
	 * @return an array of compression model.
	 * @throws Exception
	 *             if an error occurs
	 */
	public static CompressionModel[] makeCopies(CompressionModel model, int num)
			throws Exception {
		if (model == null)
			throw new Exception("No model compression model set");

		CompressionModel[] models = new CompressionModel[num];
		SerializedObject so = new SerializedObject(model);
		for (int i = 0; i < models.length; i++)
			models[i] = (CompressionModel) so.getObject();

		return models;
	}

	/**
	 * Creates a new instance of a compression model given it's class name and
	 * (optional) arguments to pass to it's setOptions method.
	 * 
	 * @param modelName
	 *            the fully qualified class name of the compression model
	 * @param options
	 *            an array of options suitable for passing to setOptions. May be
	 *            null.
	 * @return the newly created classifier, ready for use.
	 * @throws Exception
	 *             if the classifier name is invalid, or the options supplied
	 *             are not acceptable to the classifier
	 */
	public static CompressionModel forName(String modelName, String[] options)
			throws Exception {

		return (CompressionModel) Utils.forName(CompressionModel.class,
				modelName, options);
	}
}
