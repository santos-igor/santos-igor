/* HEADER
If you use this code don�t forget to reference us :) BibTeX: http://www.cs.technion.ac.il/~rani/el-yaniv_bib.html#BegleiterEY04

This code is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This code is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License (<a href="http://www.gnu.org/copyleft/gpl.html">GPL</a>) for more details.*/

package weka.classifiers.compression.vmm.algs;

import weka.classifiers.compression.vmm.pred.VMMPredictor;
import weka.classifiers.compression.vmm.pred.VMMNotTrainedException;

import weka.classifiers.compression.vmm.algs.oppm.*;

import java.io.*;

/**
 * <p>
 * <b>PPMC Predictor</b>
 * </p>
 * <p>
 * Usage example:
 * 
 * PPMCPredictor ppmc = new PPMCPredictor(); ppmc.init(256, 5);
 * ppmc.learn("abracadabra"); System.out.println("logeval : " +
 * ppmc.logEval("cadabra")); System.out.println("P(c|abra) : " +
 * ppmc.predict('c', "abra"));
 * </p>
 * 
 * Using <a href="http://www.colloquial.com/carp/">Bob Carpenter</a> code.
 * <p>
 * Copyright: Copyright (c) 2004
 * </p>
 * 
 * @author <a href="http://www.cs.technion.ac.il/~ronbeg">Ron Begleiter</a>
 * @version 1.0
 */

public final class PPMCPredictor implements VMMPredictor, Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -52983957416139962L;

	private static final double NEGTIVE_INVERSE_LOG_2 = -(1 / Math.log(2.0));

	private int abSize;

	private OfflinePPMModel ppmc;

	public PPMCPredictor() {
		ppmc = null;
	}

	/**
	 * initializes this PPMPredictor
	 * 
	 * @param abSize
	 *            alphabet size
	 * @param vmmOrder
	 *            VMM order
	 */
	public void init(int abSize, int vmmOrder) {
		this.abSize = abSize;
		ppmc = new OfflinePPMModel(vmmOrder, abSize);
	}

	public void learn(String trainingSequence) {
		String newString = "";
		try {
			newString = new String(trainingSequence.getBytes("ISO-8859-1"));
		} catch (UnsupportedEncodingException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		for (int symIndex = 0; symIndex < trainingSequence.length(); ++symIndex) {

			int symbol = (int) newString.charAt((int) symIndex);

			// If the symbol is out of the alphabet
			if (symbol < abSize) {
				ppmc.use(symbol);
			} else {
				System.out.println("JURD_ " + symbol + " " + (char) symbol);
			}

		}
	}

	public double predict(int symbol, String context) {
		try {
			ppmc.clearContext();
			for (int i = 0; i < context.length(); ++i) {
				ppmc.predict((int) context.charAt(i)); // updates the ppmc
														// context
			}
			return ppmc.predict(symbol);
		} catch (NullPointerException npe) {
			if (ppmc == null) {
				throw new VMMNotTrainedException();
			} else {
				throw npe;
			}
		}
	}

	public double logEval(String testSequence) {
		try {
			ppmc.clearContext();

			String newString = "";
			try {
				newString = new String(testSequence.getBytes("ISO-8859-1"));
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			double value = 0.0;

			for (int i = 0; i < testSequence.length(); ++i) {

				int symbol = (int) newString.charAt((int) i);

				// If the symbol is out of the alphabet
				if (symbol < abSize) {
					value += Math.log(ppmc.predict(symbol));
				} else {
					System.out.println("JURD_ " + symbol + " " + (char) symbol);
				}
			}
			return value * NEGTIVE_INVERSE_LOG_2; // the Math.log is in natural
													// base
		} catch (NullPointerException npe) {
			if (ppmc == null) {
				throw new VMMNotTrainedException();
			} else {
				throw npe;
			}
		}

	}

	public double logEval(String testSequence, String initialContext) {
		for (int symIndex = 0; symIndex < initialContext.length(); ++symIndex) {
			ppmc.use(initialContext.charAt((int) symIndex));
		}
		return logEval(testSequence);
	}

	public double logEvalAdapt(String testSequence) {
		double value = 0.0;

		String newString = "";
		try {
			newString = new String(testSequence.getBytes("ISO-8859-1"));
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		for (int symIndex = 0; symIndex < testSequence.length(); ++symIndex) {

			int symbol = (int) newString.charAt(symIndex);

			// If the symbol is out of the alphabet
			if (symbol < abSize)

			{

				value += Math.log(ppmc.predict(symbol));
				ppmc.use(testSequence.charAt((int) symIndex));

			}

		}
		return value * NEGTIVE_INVERSE_LOG_2;
	}

}
