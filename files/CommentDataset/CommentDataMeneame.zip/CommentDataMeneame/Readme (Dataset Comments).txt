*****************************************************************************

*         Dataset of commments from 'Men�ame' (April 5th to April 12th)	    *

*****************************************************************************



This dataset contains 9,044 labelled comments. The comments were extracted from 

Meneame.net every day at 10:00 AM during one week (April 5th to April 12th).
The corpus consists on LABELLED files, each corresponding to a news story.



The structure of a Meneame's story is shown below:



TITLE: is the title of the story (the same that the one in the external story).

DESCRIPTION: is the summary of the story.

TAGS: are the keywords of the story.

COMMENTS: are the reviews of the story sorted numerically.



Each comment has another line that begins with 'C:'. In this line appears the

three different classifications separated by dashes (-). This classifications
have several possible classes.



Type of Information: Opinion / Irrelevant / Contribution

Focus of the Comment: Comment / Story

Controversy Level: Normal / Controversial / Very Controversial / Joke